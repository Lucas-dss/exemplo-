function printFun() {
    alert("Você irá printar");
    window.print();
  }