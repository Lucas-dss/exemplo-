let nome = window.prompt("Qual é seu nome?") /*pergunta com resposta*/
document.write("Seja bem vindo " + nome)